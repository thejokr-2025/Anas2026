package com.anas.archive.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.data.PersonType
import com.anas.archive.ui.components.*
import com.anas.archive.util.Str

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(vm: ArchiveViewModel, t: Str, onOpenPerson: (Long) -> Unit) {
    val persons by vm.persons.collectAsState()
    val docs by vm.documents.collectAsState()
    var query by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    val expanded = remember { mutableStateMapOf<PersonType, Boolean>().apply {
        PersonType.values().forEach { put(it, true) }
    } }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text(t.searchHint) },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Filled.Close, null) }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        BigButton(t.addPerson, Icons.Filled.PersonAdd, Modifier.fillMaxWidth()) { showAdd = true }
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PersonType.values().forEach { type ->
                val list = persons.filter {
                    it.type == type && (query.isBlank() || it.name.contains(query, ignoreCase = true))
                }
                if (query.isNotBlank() && list.isEmpty()) return@forEach

                item(key = "header_$type") {
                    val col = personColor(type)
                    val isOpen = expanded[type] ?: true
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().clickable { expanded[type] = !isOpen },
                        colors = CardDefaults.cardColors(containerColor = col)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(18.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(personIcon(type), null, tint = Color.White, modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(14.dp))
                            Text(t.types[type] ?: "", color = Color.White,
                                style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                            Box(Modifier.size(34.dp).background(Color.White.copy(alpha = 0.25f), RoundedCornerShape(50)),
                                contentAlignment = Alignment.Center) {
                                Text(list.size.toString(), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(8.dp))
                            Icon(if (isOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                null, tint = Color.White)
                        }
                    }
                }

                if (expanded[type] == true) {
                    items(list, key = { "p_${it.id}" }) { person ->
                        val n = docs.count { it.personId == person.id }
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp)
                                .clickable { onOpenPerson(person.id) }
                        ) {
                            Row(Modifier.fillMaxWidth().padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Avatar(person.name.take(1), personColor(type), 44)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(person.name, style = MaterialTheme.typography.titleMedium)
                                    Text("$n ${t.docsN}", style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Icon(Icons.Filled.ChevronRight, null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (list.isEmpty()) {
                        item(key = "empty_$type") {
                            Text(t.noPersons, modifier = Modifier.padding(start = 24.dp, top = 4.dp, bottom = 4.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }

    if (showAdd) AddPersonDialog(vm, t, onDismiss = { showAdd = false })
}
