package com.anas.archive.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.data.PersonType
import com.anas.archive.ui.components.*
import com.anas.archive.util.Str

@Composable
fun AddPersonDialog(vm: ArchiveViewModel, t: Str, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(PersonType.CLIENT) }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(24.dp)) {
                Text(t.addPerson, style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(20.dp))

                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text(t.personName) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(20.dp))
                Text(t.personType, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))

                // شبكة أنواع بأزرار كبيرة
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PersonType.values().toList().chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            row.forEach { ty ->
                                val col = personColor(ty)
                                val selected = type == ty
                                Card(
                                    modifier = Modifier.weight(1f).height(90.dp).clickable { type = ty },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (selected) col else MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    border = if (selected) null
                                        else androidx.compose.foundation.BorderStroke(2.dp, col.copy(alpha = 0.3f))
                                ) {
                                    Column(
                                        Modifier.fillMaxSize(), 
                                        verticalArrangement = Arrangement.Center,
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(personIcon(ty), null, modifier = Modifier.size(30.dp),
                                            tint = if (selected) Color.White else col)
                                        Spacer(Modifier.height(6.dp))
                                        Text(t.types[ty] ?: "",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface)
                                    }
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f).height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text(t.cancel, style = MaterialTheme.typography.labelLarge) }

                    BigButton(t.save, modifier = Modifier.weight(1f)) {
                        if (name.isNotBlank()) { vm.addPerson(name, type); onDismiss() }
                    }
                }
            }
        }
    }
}
