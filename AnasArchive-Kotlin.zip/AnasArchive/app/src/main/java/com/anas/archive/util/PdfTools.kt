package com.anas.archive.util

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.itextpdf.io.image.ImageDataFactory
import com.itextpdf.kernel.pdf.PdfDocument as ITextPdfDocument
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.utils.PdfMerger
import com.itextpdf.layout.Document as ITextLayoutDocument
import com.itextpdf.layout.element.AreaBreak
import com.itextpdf.layout.element.Image as ITextImage
import java.io.File
import java.io.FileOutputStream

/**
 * ادوات PDF حقيقية تعمل داخل تطبيق اندرويد:
 * - دمج عدة صور وملفات PDF في ملف واحد (iText 7).
 * - المشاركة عبر Intent الاصلي (واتساب/بلوتوث/درايف/اي تطبيق).
 * - الطباعة عبر خدمة الطباعة الرسمية في اندرويد.
 */
object PdfTools {

    sealed class Result {
        data class Ok(val file: File) : Result()
        data class Error(val message: String) : Result()
    }

    fun buildMergedPdf(context: Context, filePaths: List<String>, outName: String): Result {
        val existing = filePaths.map { File(it) }.filter { it.exists() && it.length() > 0 }
        if (existing.isEmpty()) return Result.Error("لا توجد ملفات صالحة للدمج")

        val outFile = File(cacheShareDir(context), sanitize(outName) + ".pdf")
        var added = 0

        try {
            val writer = PdfWriter(outFile.absolutePath)
            val pdf = ITextPdfDocument(writer)
            val merger = PdfMerger(pdf)
            val layoutDoc = ITextLayoutDocument(pdf)
            var first = true

            for (f in existing) {
                try {
                    if (FileStore.isPdf(f.absolutePath)) {
                        val src = ITextPdfDocument(PdfReader(f.absolutePath))
                        merger.merge(src, 1, src.numberOfPages)
                        src.close()
                        added++
                        first = false
                    } else {
                        val bytes = f.readBytes()
                        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                        if (opts.outWidth <= 0 || opts.outHeight <= 0) continue

                        val img = ITextImage(ImageDataFactory.create(bytes))
                        img.setAutoScale(true)
                        if (!first) layoutDoc.add(AreaBreak())
                        layoutDoc.add(img)
                        added++
                        first = false
                    }
                } catch (e: Exception) {
                    // نتجاوز الملف التالف ونكمل
                }
            }

            layoutDoc.close()

            if (added == 0) {
                outFile.delete()
                return Result.Error("تعذر دمج الملفات (صيغ غير مدعومة)")
            }
            return Result.Ok(outFile)

        } catch (e: Exception) {
            try { if (outFile.exists()) outFile.delete() } catch (_: Exception) {}
            return Result.Error("خطا في انشاء PDF: " + (e.message ?: "غير معروف"))
        }
    }

    fun sharePdf(context: Context, file: File, title: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context, context.packageName + ".fileprovider", file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, title)
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (_: Exception) {
        }
    }

    fun printPdf(context: Context, file: File, jobName: String) {
        try {
            val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            val adapter = object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder(file.name)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    try {
                        file.inputStream().use { input ->
                            FileOutputStream(destination!!.fileDescriptor).use { output ->
                                input.copyTo(output)
                            }
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback?.onWriteFailed(e.message)
                    }
                }
            }
            printManager.print(jobName, adapter, null)
        } catch (e: Exception) {
            sharePdf(context, file, jobName)
        }
    }

    private fun cacheShareDir(context: Context): File =
        File(context.cacheDir, "shared").apply { if (!exists()) mkdirs() }

    private fun sanitize(s: String): String =
        s.replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(60).ifBlank { "document" }
}
