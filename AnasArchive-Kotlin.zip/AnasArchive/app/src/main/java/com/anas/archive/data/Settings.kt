package com.anas.archive.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore("settings")

object SettingsKeys {
    val LANG = stringPreferencesKey("lang")
    val DARK = booleanPreferencesKey("dark")
}

class SettingsStore(private val context: Context) {
    val lang = context.dataStore.data.map { it[SettingsKeys.LANG] ?: "ar" }
    val dark = context.dataStore.data.map { it[SettingsKeys.DARK] ?: false }

    suspend fun setLang(v: String) { context.dataStore.edit { it[SettingsKeys.LANG] = v } }
    suspend fun setDark(v: Boolean) { context.dataStore.edit { it[SettingsKeys.DARK] = v } }
}
