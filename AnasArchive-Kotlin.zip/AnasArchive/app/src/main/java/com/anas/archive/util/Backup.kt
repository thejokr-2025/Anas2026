package com.anas.archive.util

import android.content.Context
import android.net.Uri
import com.anas.archive.data.DocType
import com.anas.archive.data.Document
import com.anas.archive.data.Person
import com.anas.archive.data.PersonType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * نسخ احتياطي/استعادة حقيقي.
 * يكتب JSON يتضمن الأشخاص والمستندات، ويضمّن الملفات كـ Base64 حتى تُستعاد كاملة.
 */
object Backup {

    fun exportJson(persons: List<Person>, docs: List<Document>): String {
        val root = JSONObject()
        root.put("app", "AnasSmartArchive")
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val pArr = JSONArray()
        for (p in persons) {
            pArr.put(JSONObject().apply {
                put("id", p.id); put("name", p.name); put("type", p.type.name); put("createdAt", p.createdAt)
            })
        }
        root.put("persons", pArr)

        val dArr = JSONArray()
        for (d in docs) {
            val filesArr = JSONArray()
            for (path in d.files) {
                val f = File(path)
                if (f.exists()) {
                    filesArr.put(JSONObject().apply {
                        put("name", f.name)
                        put("data", android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP))
                    })
                }
            }
            dArr.put(JSONObject().apply {
                put("id", d.id); put("personId", d.personId); put("docType", d.docType.name)
                put("docNumber", d.docNumber); put("note", d.note); put("createdAt", d.createdAt)
                put("files", filesArr)
            })
        }
        root.put("documents", dArr)
        return root.toString()
    }

    fun writeToUri(context: Context, uri: Uri, content: String): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
            true
        } catch (e: Exception) { false }
    }

    data class RestoreData(val persons: List<Person>, val docs: List<Document>)

    /** يقرأ نسخة احتياطية ويعيد إنشاء الملفات في التخزين الداخلي. */
    fun importFromUri(context: Context, uri: Uri): RestoreData? {
        return try {
            val text = context.contentResolver.openInputStream(uri)?.use {
                it.readBytes().toString(Charsets.UTF_8)
            } ?: return null
            val root = JSONObject(text)
            if (!root.has("persons") || !root.has("documents")) return null

            val persons = mutableListOf<Person>()
            val pArr = root.getJSONArray("persons")
            for (i in 0 until pArr.length()) {
                val o = pArr.getJSONObject(i)
                persons.add(Person(
                    id = o.getLong("id"), name = o.getString("name"),
                    type = PersonType.valueOf(o.getString("type")),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                ))
            }

            val dir = File(context.filesDir, "attachments").apply { if (!exists()) mkdirs() }
            val docs = mutableListOf<Document>()
            val dArr = root.getJSONArray("documents")
            for (i in 0 until dArr.length()) {
                val o = dArr.getJSONObject(i)
                val paths = mutableListOf<String>()
                val fArr = o.optJSONArray("files") ?: JSONArray()
                for (j in 0 until fArr.length()) {
                    val fo = fArr.getJSONObject(j)
                    val bytes = android.util.Base64.decode(fo.getString("data"), android.util.Base64.NO_WRAP)
                    val ext = fo.getString("name").substringAfterLast('.', "bin")
                    val out = File(dir, "${java.util.UUID.randomUUID()}.$ext")
                    out.writeBytes(bytes)
                    paths.add(out.absolutePath)
                }
                docs.add(Document(
                    id = o.getLong("id"), personId = o.getLong("personId"),
                    docType = DocType.valueOf(o.getString("docType")),
                    docNumber = o.optString("docNumber", ""), note = o.optString("note", ""),
                    filePaths = paths.joinToString("|"),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                ))
            }
            RestoreData(persons, docs)
        } catch (e: Exception) { null }
    }
}
