package com.anas.archive.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ألوان كبدية عنابية قوية
val Burgundy       = Color(0xFF7B2D3A)
val BurgundyLight  = Color(0xFF8E3B48)
val BurgundyDark   = Color(0xFF5E2029)
val BurgundyDeep   = Color(0xFF4A1D24)
val Peach          = Color(0xFFE0A07A)
val CreamBg        = Color(0xFFFDF7F8)
val CardLight      = Color(0xFFFFFFFF)
val DarkBg         = Color(0xFF17100F)
val DarkCard       = Color(0xFF241A1C)

// ألوان أنواع الجهات (قوية)
val ClientColor    = Color(0xFF7B2D3A)
val MerchantColor  = Color(0xFF1B7F5A)
val BankColor      = Color(0xFF3A5BA0)
val OtherColor     = Color(0xFFB5691E)

private val LightColors = lightColorScheme(
    primary = Burgundy,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF6E4E7),
    onPrimaryContainer = BurgundyDeep,
    secondary = BurgundyLight,
    onSecondary = Color.White,
    tertiary = Color(0xFF3A5BA0),
    onTertiary = Color.White,
    background = CreamBg,
    onBackground = Color(0xFF2E2528),
    surface = CardLight,
    onSurface = Color(0xFF2E2528),
    surfaceVariant = Color(0xFFF3E7E9),
    onSurfaceVariant = Color(0xFF6E585B),
    error = Color(0xFFC1444B),
    outline = Color(0xFFD9B7BD)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFE0949F),
    onPrimary = BurgundyDeep,
    primaryContainer = BurgundyDark,
    onPrimaryContainer = Color(0xFFF6E4E7),
    secondary = Color(0xFFD9A0AA),
    onSecondary = BurgundyDeep,
    tertiary = Color(0xFF9BB4E8),
    onTertiary = Color(0xFF12203F),
    background = DarkBg,
    onBackground = Color(0xFFECE0E2),
    surface = DarkCard,
    onSurface = Color(0xFFECE0E2),
    surfaceVariant = Color(0xFF3A2A2D),
    onSurfaceVariant = Color(0xFFC8AAB0),
    error = Color(0xFFF2A0A5),
    outline = Color(0xFF5A4448)
)

@Composable
fun AnasTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AnasTypography,
        content = content
    )
}
