package com.anas.archive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.CompositionLocalProvider
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.ui.screens.*
import com.anas.archive.ui.theme.AnasTheme
import com.anas.archive.util.AR
import com.anas.archive.util.EN

class MainActivity : ComponentActivity() {
    private val vm: ArchiveViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark by vm.dark.collectAsState()
            val lang by vm.lang.collectAsState()
            val t = if (lang == "ar") AR else EN
            val layoutDir = if (lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

            AnasTheme(darkTheme = dark) {
                CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
                    AppRoot(vm, t)
                }
            }
        }
    }
}

enum class Tab(val icon: ImageVector) {
    HOME(Icons.Filled.Home), SEARCH(Icons.Filled.Search),
    REPORTS(Icons.Filled.BarChart), SETTINGS(Icons.Filled.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: ArchiveViewModel, t: com.anas.archive.util.Str) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var selectedPersonId by remember { mutableStateOf<Long?>(null) }

    val persons by vm.persons.collectAsState()
    val selectedPerson = persons.find { it.id == selectedPersonId }

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 8.dp) {
                val labels = mapOf(
                    Tab.HOME to t.home, Tab.SEARCH to t.search,
                    Tab.REPORTS to t.reports, Tab.SETTINGS to t.settings
                )
                Tab.values().forEach { tb ->
                    NavigationBarItem(
                        selected = tab == tb,
                        onClick = { tab = tb; if (tb != Tab.SEARCH) selectedPersonId = null },
                        icon = { Icon(tb.icon, null, modifier = Modifier.size(28.dp)) },
                        label = { Text(labels[tb] ?: "", style = MaterialTheme.typography.bodyMedium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when {
                selectedPerson != null -> PersonScreen(
                    vm = vm, t = t, person = selectedPerson,
                    onBack = { selectedPersonId = null }
                )
                tab == Tab.HOME -> HomeScreen(vm, t, onOpenPerson = { selectedPersonId = it; })
                tab == Tab.SEARCH -> SearchScreen(vm, t, onOpenPerson = { selectedPersonId = it })
                tab == Tab.REPORTS -> ReportsScreen(vm, t)
                tab == Tab.SETTINGS -> SettingsScreen(vm, t)
            }
        }
    }
}
