package com.anas.archive.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

class Converters {
    @TypeConverter fun personTypeToString(t: PersonType) = t.name
    @TypeConverter fun stringToPersonType(s: String) = PersonType.valueOf(s)
    @TypeConverter fun docTypeToString(t: DocType) = t.name
    @TypeConverter fun stringToDocType(s: String) = DocType.valueOf(s)
}

@Dao
interface ArchiveDao {
    @Query("SELECT * FROM persons ORDER BY name ASC")
    fun allPersons(): Flow<List<Person>>

    @Query("SELECT * FROM documents ORDER BY createdAt DESC")
    fun allDocuments(): Flow<List<Document>>

    @Query("SELECT * FROM documents WHERE personId = :personId ORDER BY createdAt DESC")
    fun documentsFor(personId: Long): Flow<List<Document>>

    @Insert suspend fun insertPerson(p: Person): Long
    @Update suspend fun updatePerson(p: Person)
    @Delete suspend fun deletePerson(p: Person)
    @Query("DELETE FROM documents WHERE personId = :personId")
    suspend fun deleteDocumentsOf(personId: Long)

    @Insert suspend fun insertDocument(d: Document): Long
    @Update suspend fun updateDocument(d: Document)
    @Delete suspend fun deleteDocument(d: Document)

    @Query("SELECT * FROM persons") suspend fun personsSnapshot(): List<Person>
    @Query("SELECT * FROM documents") suspend fun documentsSnapshot(): List<Document>
    @Query("DELETE FROM persons") suspend fun clearPersons()
    @Query("DELETE FROM documents") suspend fun clearDocuments()
    @Insert suspend fun insertPersons(list: List<Person>)
    @Insert suspend fun insertDocuments(list: List<Document>)
}

@Database(entities = [Person::class, Document::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class ArchiveDatabase : RoomDatabase() {
    abstract fun dao(): ArchiveDao

    companion object {
        @Volatile private var INSTANCE: ArchiveDatabase? = null
        fun get(context: Context): ArchiveDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ArchiveDatabase::class.java,
                    "anas_archive.db"
                ).build().also { INSTANCE = it }
            }
    }
}
