package com.anas.archive.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.ui.components.BigButton
import com.anas.archive.ui.components.SectionTitle
import com.anas.archive.util.Backup
import com.anas.archive.util.Str
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(vm: ArchiveViewModel, t: Str) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lang by vm.lang.collectAsState()
    val dark by vm.dark.collectAsState()

    // حفظ نسخة: يفتح مدير الملفات الحقيقي لاختيار مكان الحفظ
    val saveBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val (persons, docs) = vm.snapshot()
            val json = Backup.exportJson(persons, docs)
            val ok = Backup.writeToUri(context, uri, json)
            Toast.makeText(context, if (ok) t.savedToast else "فشل الحفظ", Toast.LENGTH_SHORT).show()
        }
    }

    // استعادة نسخة
    val openBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val data = Backup.importFromUri(context, uri)
        if (data == null) {
            Toast.makeText(context, "ملف النسخة غير صالح", Toast.LENGTH_LONG).show()
        } else {
            vm.restore(data.persons, data.docs)
            Toast.makeText(context, t.savedToast, Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(t.settings, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(20.dp))

        // اللغة
        SectionTitle(t.lang)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton(t.arabic, modifier = Modifier.weight(1f),
                container = if (lang == "ar") MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                content = if (lang == "ar") Color.White else MaterialTheme.colorScheme.onSurface
            ) { vm.setLang("ar") }
            BigButton(t.english, modifier = Modifier.weight(1f),
                container = if (lang == "en") MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                content = if (lang == "en") Color.White else MaterialTheme.colorScheme.onSurface
            ) { vm.setLang("en") }
        }

        Spacer(Modifier.height(20.dp))

        // المظهر
        SectionTitle(t.theme)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigButton(t.light, Icons.Filled.LightMode, Modifier.weight(1f),
                container = if (!dark) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                content = if (!dark) Color.White else MaterialTheme.colorScheme.onSurface
            ) { vm.setDark(false) }
            BigButton(t.dark, Icons.Filled.DarkMode, Modifier.weight(1f),
                container = if (dark) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                content = if (dark) Color.White else MaterialTheme.colorScheme.onSurface
            ) { vm.setDark(true) }
        }

        Spacer(Modifier.height(20.dp))

        // إدارة البيانات
        SectionTitle(t.dataMgmt)
        BigButton(t.backup, Icons.Filled.Save, Modifier.fillMaxWidth(),
            container = MaterialTheme.colorScheme.secondary) {
            saveBackup.launch("anas_backup_${System.currentTimeMillis()}.json")
        }
        Spacer(Modifier.height(10.dp))
        BigButton(t.restore, Icons.Filled.Restore, Modifier.fillMaxWidth(),
            container = MaterialTheme.colorScheme.secondary) {
            openBackup.launch(arrayOf("application/json"))
        }

        Spacer(Modifier.height(24.dp))

        // حول التطبيق والتواصل
        Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Archive, null, modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(10.dp))
                Text(t.app, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                Text("v1.0", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(Modifier.height(18.dp))
                Text(t.contact, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton(t.whatsapp, Icons.Filled.Chat, Modifier.weight(1f),
                        container = Color(0xFF25D366)) {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://wa.me/967773203620")))
                        } catch (_: Exception) {}
                    }
                    BigButton(t.call, Icons.Filled.Phone, Modifier.weight(1f)) {
                        try {
                            context.startActivity(Intent(Intent.ACTION_DIAL,
                                Uri.parse("tel:773203620")))
                        } catch (_: Exception) {}
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text("773203620", style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(10.dp))
                Text(t.copyright, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
