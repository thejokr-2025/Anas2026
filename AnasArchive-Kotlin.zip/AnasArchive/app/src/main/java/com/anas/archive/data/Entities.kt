package com.anas.archive.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** نوع الجهة: عميل، تاجر، بنك، أخرى */
enum class PersonType { CLIENT, MERCHANT, BANK, OTHER }

/** نوع المستند */
enum class DocType { INVOICE, RECEIPT, PAYMENT, NOTICE, RETURN, OTHER }

@Entity(tableName = "persons")
data class Person(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: PersonType,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val docType: DocType,
    val docNumber: String = "",
    val note: String = "",
    /** مسارات الملفات المرفقة داخل تخزين التطبيق، مفصولة بفاصل | */
    val filePaths: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    val files: List<String>
        get() = if (filePaths.isBlank()) emptyList() else filePaths.split("|").filter { it.isNotBlank() }
}
