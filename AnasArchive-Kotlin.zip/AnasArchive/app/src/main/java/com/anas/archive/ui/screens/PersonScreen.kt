package com.anas.archive.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.data.Document
import com.anas.archive.data.Person
import com.anas.archive.ui.components.*
import com.anas.archive.util.PdfTools
import com.anas.archive.util.Str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PersonScreen(vm: ArchiveViewModel, t: Str, person: Person, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val allDocs by vm.documents.collectAsState()
    val docs = allDocs.filter { it.personId == person.id }
    val col = personColor(person.type)

    var showAddDoc by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var confirmDeletePerson by remember { mutableStateOf(false) }
    var docToDelete by remember { mutableStateOf<Document?>(null) }

    /** يجمع كل مرفقات الشخص ويدمجها في PDF واحد ثم يشارك أو يطبع. */
    fun buildAndDo(print: Boolean) {
        val paths = docs.flatMap { it.files }
        if (paths.isEmpty()) {
            Toast.makeText(context, t.emptyFiles, Toast.LENGTH_SHORT).show(); return
        }
        busy = true
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                PdfTools.buildMergedPdf(context, paths, person.name)
            }
            busy = false
            when (result) {
                is PdfTools.Result.Ok ->
                    if (print) PdfTools.printPdf(context, result.file, person.name)
                    else PdfTools.sharePdf(context, result.file, person.name)
                is PdfTools.Result.Error ->
                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(person.name, style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onBack) { Icon(Icons.Filled.ArrowBack, null, modifier = Modifier.size(28.dp)) }
                },
                actions = {
                    IconButton({ confirmDeletePerson = true }) {
                        Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(26.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = col, titleContentColor = Color.White,
                    navigationIconContentColor = Color.White, actionIconContentColor = Color.White
                )
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {

            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(person.name.take(1), col, 64)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(t.types[person.type] ?: "", style = MaterialTheme.typography.titleMedium, color = col)
                    Text("${docs.size} ${t.docsN} · ${docs.sumOf { it.files.size }} ${t.filesN}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(20.dp))
            BigButton(t.addDoc, Icons.Filled.Add, Modifier.fillMaxWidth()) { showAddDoc = true }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton(t.shareAll, Icons.Filled.Share, Modifier.weight(1f),
                    container = MaterialTheme.colorScheme.secondary) { buildAndDo(false) }
                BigButton(t.print, Icons.Filled.Print, Modifier.weight(1f),
                    container = MaterialTheme.colorScheme.tertiary,
                    content = MaterialTheme.colorScheme.onTertiary) { buildAndDo(true) }
            }

            if (busy) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(t.building, style = MaterialTheme.typography.bodyLarge)
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionTitle(t.totalDocs)

            if (docs.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                    Text(t.noDocs, style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(docs, key = { it.id }) { doc ->
                        DocCard(doc, t, onDelete = { docToDelete = doc },
                            onShare = {
                                if (doc.files.isEmpty()) {
                                    Toast.makeText(context, t.emptyFiles, Toast.LENGTH_SHORT).show()
                                } else {
                                    busy = true
                                    scope.launch {
                                        val r = withContext(Dispatchers.IO) {
                                            PdfTools.buildMergedPdf(context, doc.files,
                                                "${person.name}_${t.docTypes[doc.docType]}")
                                        }
                                        busy = false
                                        when (r) {
                                            is PdfTools.Result.Ok -> PdfTools.sharePdf(context, r.file, person.name)
                                            is PdfTools.Result.Error ->
                                                Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            })
                    }
                    item { Spacer(Modifier.height(20.dp)) }
                }
            }
        }
    }

    if (showAddDoc) AddDocumentDialog(vm, t, person, onDismiss = { showAddDoc = false })

    if (confirmDeletePerson) {
        AlertDialog(
            onDismissRequest = { confirmDeletePerson = false },
            title = { Text(t.delete, style = MaterialTheme.typography.titleLarge) },
            text = { Text(t.deleteConfirm, style = MaterialTheme.typography.bodyLarge) },
            confirmButton = {
                TextButton({ vm.deletePerson(person); confirmDeletePerson = false; onBack() }) {
                    Text(t.yes, color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelLarge)
                }
            },
            dismissButton = {
                TextButton({ confirmDeletePerson = false }) {
                    Text(t.no, style = MaterialTheme.typography.labelLarge)
                }
            }
        )
    }

    docToDelete?.let { d ->
        AlertDialog(
            onDismissRequest = { docToDelete = null },
            title = { Text(t.delete, style = MaterialTheme.typography.titleLarge) },
            text = { Text(t.deleteConfirm, style = MaterialTheme.typography.bodyLarge) },
            confirmButton = {
                TextButton({ vm.deleteDocument(d); docToDelete = null }) {
                    Text(t.yes, color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelLarge)
                }
            },
            dismissButton = {
                TextButton({ docToDelete = null }) { Text(t.no, style = MaterialTheme.typography.labelLarge) }
            }
        )
    }
}

@Composable
private fun DocCard(doc: Document, t: Str, onDelete: () -> Unit, onShare: () -> Unit) {
    val dc = docColor(doc.docType)
    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(dc, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Description, null, tint = Color.White, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(t.docTypes[doc.docType] ?: "", style = MaterialTheme.typography.titleMedium)
                if (doc.docNumber.isNotBlank())
                    Text("${t.docNumber}: ${doc.docNumber}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (doc.note.isNotBlank())
                    Text(doc.note, style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                if (doc.files.isNotEmpty())
                    Text("${doc.files.size} ${t.filesN}",
                        style = MaterialTheme.typography.bodyMedium, color = dc)
            }
            IconButton(onShare) { Icon(Icons.Filled.Share, null, modifier = Modifier.size(24.dp)) }
            IconButton(onDelete) {
                Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(24.dp))
            }
        }
    }
}
