package com.anas.archive.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.data.DocType
import com.anas.archive.data.Person
import com.anas.archive.ui.components.*
import com.anas.archive.util.FileStore
import com.anas.archive.util.Str
import java.io.File

@Composable
fun AddDocumentDialog(vm: ArchiveViewModel, t: Str, person: Person, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var docType by remember { mutableStateOf(DocType.INVOICE) }
    var docNumber by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val paths = remember { mutableStateListOf<String>() }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    // اختيار عدة ملفات/صور دفعة واحدة
    val pickFiles = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            FileStore.copyIn(context, uri)?.let { paths.add(it) }
        }
    }

    // التقاط صورة بالكاميرا
    val takePhoto = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) cameraUri?.let { uri -> FileStore.copyIn(context, uri)?.let { paths.add(it) } }
    }

    fun launchCamera() {
        try {
            val dir = File(context.cacheDir, "camera").apply { if (!exists()) mkdirs() }
            val f = File(dir, "cam_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
            cameraUri = uri
            takePhoto.launch(uri)
        } catch (_: Exception) {}
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(22.dp).verticalScroll(rememberScrollState())) {
                Text(t.addDoc, style = MaterialTheme.typography.headlineMedium)
                Text(person.name, style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(Modifier.height(18.dp))
                Text(t.docType, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DocType.values().toList().chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { dt ->
                                val c = docColor(dt)
                                val sel = docType == dt
                                Card(
                                    modifier = Modifier.weight(1f).height(54.dp).clickable { docType = dt },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (sel) c else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                ) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text(t.docTypes[dt] ?: "",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface)
                                    }
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = docNumber, onValueChange = { docNumber = it },
                    label = { Text(t.docNumber) }, singleLine = true,
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text(t.note) }, placeholder = { Text(t.notePh) },
                    minLines = 2, maxLines = 4,
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(18.dp))
                Text(t.attach, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton(t.addFiles, Icons.Filled.AttachFile, Modifier.weight(1f),
                        container = MaterialTheme.colorScheme.secondary) {
                        pickFiles.launch(arrayOf("image/*", "application/pdf"))
                    }
                    BigButton(t.camera, Icons.Filled.PhotoCamera, Modifier.weight(1f),
                        container = MaterialTheme.colorScheme.secondary) { launchCamera() }
                }

                if (paths.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(paths) { i, p ->
                            Box(Modifier.size(84.dp)) {
                                if (FileStore.isImage(p)) {
                                    AsyncImage(
                                        model = File(p), contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                                    )
                                } else {
                                    Box(Modifier.fillMaxSize()
                                        .background(MaterialTheme.colorScheme.surfaceVariant,
                                            RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.PictureAsPdf, null, modifier = Modifier.size(34.dp))
                                    }
                                }
                                IconButton(
                                    onClick = { FileStore.delete(p); paths.removeAt(i) },
                                    modifier = Modifier.align(Alignment.TopEnd).size(26.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(50))
                                ) {
                                    Icon(Icons.Filled.Close, null, tint = Color.White,
                                        modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = { paths.forEach { FileStore.delete(it) }; onDismiss() },
                        modifier = Modifier.weight(1f).height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text(t.cancel, style = MaterialTheme.typography.labelLarge) }

                    BigButton(t.save, modifier = Modifier.weight(1f)) {
                        vm.addDocument(person.id, docType, docNumber, note, paths.toList())
                        onDismiss()
                    }
                }
            }
        }
    }
}
