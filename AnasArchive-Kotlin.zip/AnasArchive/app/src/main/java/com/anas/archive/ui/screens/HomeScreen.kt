package com.anas.archive.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.data.PersonType
import com.anas.archive.ui.components.*
import com.anas.archive.ui.theme.Burgundy
import com.anas.archive.ui.theme.BurgundyDark
import com.anas.archive.util.Str

@Composable
fun HomeScreen(vm: ArchiveViewModel, t: Str, onOpenPerson: (Long) -> Unit) {
    val persons by vm.persons.collectAsState()
    val docs by vm.documents.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        // Hero banner
        Card(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(Modifier.background(Brush.linearGradient(listOf(Burgundy, BurgundyDark))).padding(24.dp)) {
                Column {
                    Text(t.app, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        StatBox(persons.size.toString(), t.totalPersons, Modifier.weight(1f))
                        StatBox(docs.size.toString(), t.totalDocs, Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        SectionTitle(t.allTypes)

        // Vertical type list
        PersonType.values().forEach { type ->
            val list = persons.filter { it.type == type }
            val col = personColor(type)
            Card(
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).background(col, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center) {
                        Icon(personIcon(type), null, tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.types[type] ?: "", style = MaterialTheme.typography.titleMedium)
                        Text("${list.size} ${t.totalPersons}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box(Modifier.size(36.dp).background(col.copy(alpha = 0.15f), RoundedCornerShape(50)),
                        contentAlignment = Alignment.Center) {
                        Text(list.size.toString(), color = col, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        BigButton(t.addPerson, Icons.Filled.Add, Modifier.fillMaxWidth()) { showAdd = true }
        Spacer(Modifier.height(24.dp))
    }

    if (showAdd) AddPersonDialog(vm, t, onDismiss = { showAdd = false })
}

@Composable
private fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(16.dp)).padding(16.dp)
    ) {
        Text(value, style = MaterialTheme.typography.headlineLarge, color = Color.White)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.9f))
    }
}
