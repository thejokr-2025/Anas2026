package com.anas.archive.util

import com.anas.archive.data.DocType
import com.anas.archive.data.PersonType

data class Str(
    val app: String, val home: String, val search: String, val reports: String, val settings: String,
    val addPerson: String, val personName: String, val personType: String, val save: String, val cancel: String,
    val addDoc: String, val docType: String, val docNumber: String, val note: String, val notePh: String,
    val attach: String, val addFiles: String, val camera: String,
    val noPersons: String, val noDocs: String, val share: String, val shareAll: String, val print: String,
    val delete: String, val edit: String, val totalPersons: String, val totalDocs: String, val filesN: String, val docsN: String,
    val lang: String, val theme: String, val light: String, val dark: String, val arabic: String, val english: String,
    val backup: String, val restore: String, val localBackup: String, val dataMgmt: String, val about: String,
    val contact: String, val call: String, val whatsapp: String, val copyright: String,
    val searchHint: String, val noResults: String, val deleteConfirm: String, val yes: String, val no: String,
    val savedToast: String, val deletedToast: String, val building: String, val allTypes: String, val primaryType: String,
    val recent: String, val noActivity: String, val chooseType: String, val exportPdf: String, val emptyFiles: String,
    val types: Map<PersonType, String>, val docTypes: Map<DocType, String>
)

val AR = Str(
    app = "أنس للأرشفة الذكية", home = "الرئيسية", search = "بحث", reports = "التقارير", settings = "الإعدادات",
    addPerson = "إضافة شخص", personName = "اسم الشخص", personType = "نوع الجهة", save = "حفظ", cancel = "إلغاء",
    addDoc = "إضافة مستند", docType = "نوع المستند", docNumber = "رقم المستند", note = "ملاحظة", notePh = "اكتب ملاحظة...",
    attach = "المرفقات", addFiles = "اختيار صور أو ملفات", camera = "التقاط بالكاميرا",
    noPersons = "لا توجد أسماء", noDocs = "لا توجد مستندات", share = "مشاركة", shareAll = "مشاركة كل الملفات PDF", print = "طباعة",
    delete = "حذف", edit = "تعديل", totalPersons = "الأسماء", totalDocs = "المستندات", filesN = "ملف", docsN = "مستند",
    lang = "اللغة", theme = "المظهر", light = "فاتح", dark = "داكن", arabic = "العربية", english = "English",
    backup = "حفظ نسخة احتياطية", restore = "استعادة نسخة", localBackup = "النسخ الاحتياطي", dataMgmt = "إدارة البيانات", about = "حول التطبيق",
    contact = "للتواصل مع المهندس أنس", call = "اتصال", whatsapp = "واتساب", copyright = "جميع الحقوق محفوظة © م. أنس",
    searchHint = "ابحث بالاسم...", noResults = "لا توجد نتائج", deleteConfirm = "لا يمكن التراجع عن هذا الإجراء", yes = "حذف", no = "إلغاء",
    savedToast = "تم الحفظ", deletedToast = "تم الحذف", building = "جاري التجهيز...", allTypes = "جميع الأنواع", primaryType = "النوع الأساسي",
    recent = "آخر النشاطات", noActivity = "لا توجد نشاطات", chooseType = "اختر النوع", exportPdf = "تقرير PDF", emptyFiles = "لا توجد ملفات للمشاركة",
    types = mapOf(
        PersonType.CLIENT to "عميل", PersonType.MERCHANT to "تاجر",
        PersonType.BANK to "بنك", PersonType.OTHER to "أخرى"
    ),
    docTypes = mapOf(
        DocType.INVOICE to "فاتورة", DocType.RECEIPT to "سند قبض", DocType.PAYMENT to "سند صرف",
        DocType.NOTICE to "إشعار", DocType.RETURN to "مردود", DocType.OTHER to "أخرى"
    )
)

val EN = Str(
    app = "Anas Smart Archive", home = "Home", search = "Search", reports = "Reports", settings = "Settings",
    addPerson = "Add Person", personName = "Person Name", personType = "Type", save = "Save", cancel = "Cancel",
    addDoc = "Add Document", docType = "Document Type", docNumber = "Doc Number", note = "Note", notePh = "Write a note...",
    attach = "Attachments", addFiles = "Choose photos or files", camera = "Take photo",
    noPersons = "No names", noDocs = "No documents", share = "Share", shareAll = "Share all as PDF", print = "Print",
    delete = "Delete", edit = "Edit", totalPersons = "Persons", totalDocs = "Documents", filesN = "files", docsN = "docs",
    lang = "Language", theme = "Theme", light = "Light", dark = "Dark", arabic = "العربية", english = "English",
    backup = "Save backup", restore = "Restore backup", localBackup = "Backup", dataMgmt = "Data management", about = "About",
    contact = "Contact Eng. Anas", call = "Call", whatsapp = "WhatsApp", copyright = "All rights reserved © Eng. Anas",
    searchHint = "Search by name...", noResults = "No results", deleteConfirm = "This cannot be undone", yes = "Delete", no = "Cancel",
    savedToast = "Saved", deletedToast = "Deleted", building = "Preparing...", allTypes = "All types", primaryType = "Primary type",
    recent = "Recent", noActivity = "No activity", chooseType = "Choose type", exportPdf = "PDF report", emptyFiles = "No files to share",
    types = mapOf(
        PersonType.CLIENT to "Client", PersonType.MERCHANT to "Merchant",
        PersonType.BANK to "Bank", PersonType.OTHER to "Other"
    ),
    docTypes = mapOf(
        DocType.INVOICE to "Invoice", DocType.RECEIPT to "Receipt", DocType.PAYMENT to "Payment",
        DocType.NOTICE to "Notice", DocType.RETURN to "Return", DocType.OTHER to "Other"
    )
)
