package com.anas.archive.util

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

/** ينسخ ملفاً مختاراً من الهاتف إلى تخزين التطبيق الخاص ويعيد المسار. */
object FileStore {

    private fun dir(context: Context): File =
        File(context.filesDir, "attachments").apply { if (!exists()) mkdirs() }

    /**
     * ينسخ الـ Uri إلى ملف داخلي. يعيد المسار المطلق أو null عند الفشل.
     * يحدد الامتداد من نوع المحتوى الحقيقي.
     */
    fun copyIn(context: Context, uri: Uri): String? {
        return try {
            val resolver = context.contentResolver
            val mime = resolver.getType(uri) ?: ""
            val ext = when {
                mime.contains("pdf") -> "pdf"
                mime.contains("png") -> "png"
                mime.contains("webp") -> "webp"
                mime.contains("heic") || mime.contains("heif") -> "heic"
                mime.contains("jpeg") || mime.contains("jpg") -> "jpg"
                else -> guessExtFromName(context, uri) ?: "bin"
            }
            val out = File(dir(context), "${UUID.randomUUID()}.$ext")
            resolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            if (out.length() == 0L) { out.delete(); return null }
            out.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun guessExtFromName(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) {
                    val name = c.getString(idx)
                    name.substringAfterLast('.', "").ifBlank { null }
                } else null
            }
        } catch (e: Exception) { null }
    }

    /** يحذف ملفاً من التخزين الداخلي. */
    fun delete(path: String) {
        try { File(path).takeIf { it.exists() }?.delete() } catch (_: Exception) {}
    }

    fun isImage(path: String): Boolean {
        val p = path.lowercase()
        return p.endsWith(".jpg") || p.endsWith(".jpeg") || p.endsWith(".png") ||
                p.endsWith(".webp") || p.endsWith(".heic") || p.endsWith(".heif")
    }

    fun isPdf(path: String): Boolean = path.lowercase().endsWith(".pdf")
}
