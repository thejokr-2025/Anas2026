package com.anas.archive.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.anas.archive.data.ArchiveViewModel
import com.anas.archive.data.DocType
import com.anas.archive.data.PersonType
import com.anas.archive.ui.components.*
import com.anas.archive.util.PdfTools
import com.anas.archive.util.Str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ReportsScreen(vm: ArchiveViewModel, t: Str) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val persons by vm.persons.collectAsState()
    val docs by vm.documents.collectAsState()

    // null = جميع الأنواع
    var filter by remember { mutableStateOf<PersonType?>(null) }
    var busy by remember { mutableStateOf(false) }

    val shown = persons.filter { filter == null || it.type == filter }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(t.reports, style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))

        // النوع الأساسي
        SectionTitle(t.primaryType)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipBig(t.allTypes, filter == null, MaterialTheme.colorScheme.primary) { filter = null }
            PersonType.values().toList().chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { ty ->
                        Box(Modifier.weight(1f)) {
                            FilterChipBig(t.types[ty] ?: "", filter == ty, personColor(ty)) { filter = ty }
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // إحصاءات
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(shown.size.toString(), t.totalPersons,
                MaterialTheme.colorScheme.primary, Modifier.weight(1f))
            val dcount = docs.count { d -> shown.any { it.id == d.personId } }
            StatCard(dcount.toString(), t.totalDocs,
                MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
        }

        Spacer(Modifier.height(18.dp))

        // توزيع أنواع المستندات
        SectionTitle(t.docType)
        Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                val relevant = docs.filter { d -> shown.any { it.id == d.personId } }
                val maxV = DocType.values().maxOf { dt -> relevant.count { it.docType == dt } }.coerceAtLeast(1)
                DocType.values().forEach { dt ->
                    val c = relevant.count { it.docType == dt }
                    Column(Modifier.padding(vertical = 6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(t.docTypes[dt] ?: "", style = MaterialTheme.typography.bodyLarge)
                            Text(c.toString(), style = MaterialTheme.typography.titleMedium, color = docColor(dt))
                        }
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(12.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))) {
                            Box(Modifier.fillMaxWidth(c.toFloat() / maxV).fillMaxHeight()
                                .background(docColor(dt), RoundedCornerShape(8.dp)))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // تفاصيل كل شخص (بدون تاريخ)
        SectionTitle(t.totalPersons)
        shown.forEach { p ->
            val pd = docs.filter { it.personId == p.id }
            Card(shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(p.name.take(1), personColor(p.type), 44)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium)
                        Text(t.types[p.type] ?: "", style = MaterialTheme.typography.bodyMedium,
                            color = personColor(p.type))
                    }
                    Text("${pd.size} ${t.docsN}", style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // تصدير تقرير PDF لكل ملفات الفئة المختارة
        BigButton(t.exportPdf, Icons.Filled.PictureAsPdf, Modifier.fillMaxWidth()) {
            val paths = docs.filter { d -> shown.any { it.id == d.personId } }.flatMap { it.files }
            if (paths.isEmpty()) {
                Toast.makeText(context, t.emptyFiles, Toast.LENGTH_SHORT).show()
            } else {
                busy = true
                scope.launch {
                    val r = withContext(Dispatchers.IO) {
                        PdfTools.buildMergedPdf(context, paths,
                            "${t.reports}_${filter?.let { t.types[it] } ?: t.allTypes}")
                    }
                    busy = false
                    when (r) {
                        is PdfTools.Result.Ok -> PdfTools.sharePdf(context, r.file, t.reports)
                        is PdfTools.Result.Error -> Toast.makeText(context, r.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        if (busy) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 3.dp)
                Spacer(Modifier.width(12.dp))
                Text(t.building, style = MaterialTheme.typography.bodyLarge)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FilterChipBig(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().height(52.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) color else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(label, style = MaterialTheme.typography.titleMedium,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface)
        }
    }
}
