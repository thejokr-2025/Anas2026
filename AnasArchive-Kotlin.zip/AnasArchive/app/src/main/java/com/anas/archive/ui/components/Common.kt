package com.anas.archive.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.anas.archive.data.DocType
import com.anas.archive.data.PersonType
import com.anas.archive.ui.theme.*

fun personColor(type: PersonType): Color = when (type) {
    PersonType.CLIENT -> ClientColor
    PersonType.MERCHANT -> MerchantColor
    PersonType.BANK -> BankColor
    PersonType.OTHER -> OtherColor
}

fun personIcon(type: PersonType): ImageVector = when (type) {
    PersonType.CLIENT -> Icons.Filled.Person
    PersonType.MERCHANT -> Icons.Filled.Storefront
    PersonType.BANK -> Icons.Filled.AccountBalance
    PersonType.OTHER -> Icons.Filled.Folder
}

fun docColor(type: DocType): Color = when (type) {
    DocType.INVOICE -> Color(0xFF3A5BA0)
    DocType.RECEIPT -> Color(0xFF1B7F5A)
    DocType.PAYMENT -> Color(0xFFB5691E)
    DocType.NOTICE -> Color(0xFF7B2D3A)
    DocType.RETURN -> Color(0xFFC1444B)
    DocType.OTHER -> Color(0xFF6E585B)
}

/** زر كبير رئيسي بلون قوي. */
@Composable
fun BigButton(
    text: String,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    container: Color = MaterialTheme.colorScheme.primary,
    content: Color = MaterialTheme.colorScheme.onPrimary,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = content)
    ) {
        if (icon != null) {
            Icon(icon, null, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

/** بطاقة إحصائية كبيرة. */
@Composable
fun StatCard(value: String, label: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(value, style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(label, style = MaterialTheme.typography.bodyLarge, color = Color.White.copy(alpha = 0.9f))
        }
    }
}

@Composable
fun Avatar(letter: String, color: Color, size: Int = 48) {
    Box(
        Modifier.size(size.dp).background(color, RoundedCornerShape(percent = 50)),
        contentAlignment = Alignment.Center
    ) {
        Text(letter, color = Color.White, fontWeight = FontWeight.ExtraBold,
            style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp))
}
