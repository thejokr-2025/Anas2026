package com.anas.archive.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.anas.archive.util.FileStore
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ArchiveViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = ArchiveDatabase.get(app).dao()
    private val settings = SettingsStore(app)

    val persons = dao.allPersons().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val documents = dao.allDocuments().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val lang = settings.lang.stateIn(viewModelScope, SharingStarted.Eagerly, "ar")
    val dark = settings.dark.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun setLang(v: String) = viewModelScope.launch { settings.setLang(v) }
    fun setDark(v: Boolean) = viewModelScope.launch { settings.setDark(v) }

    fun docsOf(personId: Long) = documents.value.filter { it.personId == personId }

    fun addPerson(name: String, type: PersonType) = viewModelScope.launch {
        dao.insertPerson(Person(name = name.trim(), type = type))
    }
    fun updatePerson(p: Person) = viewModelScope.launch { dao.updatePerson(p) }

    fun deletePerson(p: Person) = viewModelScope.launch {
        docsOf(p.id).forEach { d -> d.files.forEach { FileStore.delete(it) } }
        dao.deleteDocumentsOf(p.id)
        dao.deletePerson(p)
    }

    fun addDocument(personId: Long, type: DocType, docNumber: String, note: String, paths: List<String>) =
        viewModelScope.launch {
            dao.insertDocument(Document(
                personId = personId, docType = type, docNumber = docNumber.trim(),
                note = note.trim(), filePaths = paths.joinToString("|")
            ))
        }

    fun updateDocument(d: Document) = viewModelScope.launch { dao.updateDocument(d) }

    fun deleteDocument(d: Document) = viewModelScope.launch {
        d.files.forEach { FileStore.delete(it) }
        dao.deleteDocument(d)
    }

    suspend fun snapshot(): Pair<List<Person>, List<Document>> =
        dao.personsSnapshot() to dao.documentsSnapshot()

    fun restore(persons: List<Person>, docs: List<Document>) = viewModelScope.launch {
        documents.value.forEach { d -> d.files.forEach { FileStore.delete(it) } }
        dao.clearDocuments(); dao.clearPersons()
        dao.insertPersons(persons); dao.insertDocuments(docs)
    }
}
